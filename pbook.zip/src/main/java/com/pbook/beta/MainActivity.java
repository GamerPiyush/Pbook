package com.pbook.beta;
 
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebStorage;
import android.webkit.WebSettings;

public class MainActivity extends Activity { 
WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		web = (WebView) findViewById(R.id.webview);
		WebSettings Set = web.getSettings();
		web.loadUrl("http://pbook.epizy.com");
		Set.setAppCacheEnabled(false);
		Set.setSaveFormData(false);
		Set.setJavaScriptEnabled(true);
		web.setWebViewClient(new WebViewClient());
		
    }

	@Override
	public void onBackPressed() {
		if(web.canGoBack()){
			web.goBack();
		}
	}
} 
